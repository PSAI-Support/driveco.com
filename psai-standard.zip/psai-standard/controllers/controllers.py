# -*- coding: utf-8 -*-
# from odoo import http


# class C:\odoo\local-addons\driveco.com\psai-standard(http.Controller):
#     @http.route('/c:\odoo\local-addons\driveco.com\psai-standard/c:\odoo\local-addons\driveco.com\psai-standard/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/c:\odoo\local-addons\driveco.com\psai-standard/c:\odoo\local-addons\driveco.com\psai-standard/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('c:\odoo\local-addons\driveco.com\psai-standard.listing', {
#             'root': '/c:\odoo\local-addons\driveco.com\psai-standard/c:\odoo\local-addons\driveco.com\psai-standard',
#             'objects': http.request.env['c:\odoo\local-addons\driveco.com\psai-standard.c:\odoo\local-addons\driveco.com\psai-standard'].search([]),
#         })

#     @http.route('/c:\odoo\local-addons\driveco.com\psai-standard/c:\odoo\local-addons\driveco.com\psai-standard/objects/<model("c:\odoo\local-addons\driveco.com\psai-standard.c:\odoo\local-addons\driveco.com\psai-standard"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('c:\odoo\local-addons\driveco.com\psai-standard.object', {
#             'object': obj
#         })
