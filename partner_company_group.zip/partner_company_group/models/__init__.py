from . import res_partner
from . import crm_lead
from . import sale_order
from . import account_move
