This Module adds a company group field to companies, which is also propagated to contacts and allows to search and group for the company group in contact, leads, sale orders and invoices.
