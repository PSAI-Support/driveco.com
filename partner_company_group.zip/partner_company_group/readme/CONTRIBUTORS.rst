* Timon Tschanz <timon.tschanz@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
